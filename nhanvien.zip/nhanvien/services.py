from .models import NhanVien

def danh_sach_nhan_vien():
    """
    Lấy danh sách tất cả nhân viên.
    Trả về QuerySet chứa tất cả các đối tượng NhanVien.
    """
    return NhanVien.objects.all()

def thong_tin_nv(manv):
    """
    Lấy thông tin chi tiết của một nhân viên theo mã nhân viên (manv).
    Sử dụng select_related để tối ưu hóa truy vấn liên quan đến maPB và maCV.
    Trả về đối tượng NhanVien hoặc None nếu không tìm thấy.
    """
    return NhanVien.objects.filter(maNV=manv).select_related('maPB', 'maCV').first()

def danh_sach_nhan_vien_theo_ma_nv(maNV):
    """
    Lấy danh sách nhân viên có mã nhân viên (maNV) cụ thể.
    Trả về QuerySet các đối tượng NhanVien có mã nhân viên tương ứng.
    """
    return NhanVien.objects.filter(maNV=maNV)

def danh_sach_ten_nhan_vien(maNV):
    """
    Lấy tên của nhân viên dựa trên mã nhân viên (maNV).
    Trả về tên của nhân viên hoặc None nếu không tìm thấy.
    """
    nv = NhanVien.objects.filter(maNV=maNV).first()
    return nv.tenNV if nv else None

def kiem_tra_dang_nhap_nv(maNV, matKhau):
    """
    Kiểm tra đăng nhập của nhân viên bằng mã nhân viên và mật khẩu.
    Trả về True nếu thông tin đăng nhập hợp lệ, ngược lại trả về False.
    """
    return NhanVien.objects.filter(maNV=maNV, matKhau=matKhau).exists()

def them_nhan_vien(data):
    """
    Thêm nhân viên mới vào cơ sở dữ liệu.
    Trả về True nếu thêm thành công, ngược lại trả về False nếu nhân viên đã tồn tại.
    """
    if not NhanVien.objects.filter(maNV=data['maNV']).exists():
        nhan_vien = NhanVien(**data)
        nhan_vien.save()
        return True
    return False

def chinh_sua_nhan_vien(maNV_cu, data):
    """
    Cập nhật thông tin nhân viên.
    Trả về True nếu cập nhật thành công, ngược lại trả về False.
    """
    if maNV_cu == data['maNV'] or not NhanVien.objects.filter(maNV=data['maNV']).exists():
        NhanVien.objects.filter(maNV=maNV_cu).update(**data)
        return True
    return False

def xoa_nhan_vien(maNV):
    """
    Xóa nhân viên khỏi cơ sở dữ liệu theo mã nhân viên (maNV).
    Trả về True nếu xóa thành công, ngược lại trả về False.
    """
    try:
        NhanVien.objects.filter(maNV=maNV).delete()
        return True
    except NhanVien.DoesNotExist:
        return False
