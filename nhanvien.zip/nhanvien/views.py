from rest_framework import viewsets
from rest_framework.response import Response
from .models import NhanVien
from .serializers import NhanVienSerializer
from django.shortcuts import get_object_or_404
from . import services
from django.shortcuts import render
from trangchu.views import check_session

class NhanVienViewSet(viewsets.ViewSet):

    def list(self, request):
        queryset = services.danh_sach_nhan_vien()
        serializer = NhanVienSerializer(queryset, many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk=None):
        nv = services.thong_tin_nv(pk)
        if nv:
            serializer = NhanVienSerializer(nv)
            return Response(serializer.data)
        return Response({"error": "Not found"}, status=404)

    def create(self, request):
        if services.them_nhan_vien(request.data):
            return Response(request.data, status=201)
        return Response({"error": "Could not create employee"}, status=400)

    def update(self, request, pk=None):
        if services.chinh_sua_nhan_vien(pk, request.data):
            return Response(request.data)
        return Response({"error": "Could not update employee"}, status=400)

    def destroy(self, request, pk=None):
        if services.xoa_nhan_vien(pk):
            return Response(status=204)
        return Response({"error": "Could not delete employee"}, status=400)


@check_session
def index(request):
    if request.session.get("member_id"):
        context = {
            "user_name": request.session.get("member_id")
        }
        return render(request, "nhanvien/index.html", context)
    
    from nhanvien.services import danh_sach_nhan_vien


def nhanvien(request):
    return render(request, 'nhanvien/index.html')