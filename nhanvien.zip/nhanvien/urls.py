from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import NhanVienViewSet, nhanvien
from . import views

router = DefaultRouter()
router.register(r'nhanvien', NhanVienViewSet, basename='nhanvien')
app_name = "nhanvien"
urlpatterns = [
    path('', include(router.urls)),
    path("", views.index, name="index"),
    path("nhanvien/", nhanvien, name="nhanvien")
]
