from django.db import models


class NhanVien(models.Model):
    maNV = models.CharField(max_length=12, primary_key=True)
    tenNV = models.CharField(max_length=200)
    Manhomnd = models.CharField(max_length=200)
    Matkhau = models.CharField(max_length=200)
    Diachi = models.CharField(max_length=200)
    gioiTinh = models.CharField(max_length=5)
    Ngaysinh = models.DateField()
    Dantoc = models.TextField()
    Sdt = models.TextField()
    Email = models.CharField(max_length=200)
    Honnhan = models.TextField()
    soCMT = models.CharField(max_length=12)
    Noicap = models.CharField(max_length=200)
    Tongiao = models.TextField()
    Quoctich = models.CharField(max_length=200)
    MaCV = models.CharField(max_length=200)
    maPB = models.IntegerField()
    anhNV = models.CharField(max_length=250)
    loainv = models.BooleanField(default=False)
    nguoitao = models.CharField(max_length=12)
    maTC = models.IntegerField()

    class Meta:
        db_table = 'nhanviens'
