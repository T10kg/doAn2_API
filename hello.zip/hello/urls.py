



# myapp/urls.py
from django.urls import path
from .views import ProductListView, product_list_view, add_product_view

urlpatterns = [
    path('api/products/', ProductListView.as_view(), name='product-list'),  # URL cho API
    path('products/', product_list_view, name='product-list-view'),  # URL cho template
    path('add-product/', add_product_view, name='add-product'),
]



