# myapp/views.py
from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Product
from .serializers import ProductSerializerlist , ProductSerializeradd

class ProductListView(APIView):
    def get(self, request):
        products = Product.objects.all()[:5]  # Lấy 5 sản phẩm đầu tiên
        serializer = ProductSerializerlist(products, many=True)
        return Response(serializer.data)


# myapp/views.py

class ProductCreateView(APIView):
    def post(self, request):
        serializer = ProductSerializeradd(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

def add_product_view(request):
    return render(request, 'hello/add.html')




def product_list_view(request):
    return render(request, 'hello/test.html')



